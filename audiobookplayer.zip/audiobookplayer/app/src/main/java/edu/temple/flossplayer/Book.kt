package edu.temple.flossplayer

import android.provider.Settings.Global.putInt
import edu.temple.flossaudioplayer.AudioBookPlayerService
import org.json.JSONObject
import java.io.File
import java.io.Serializable
import java.time.LocalDateTime

// JSON Book object keys
const val ID = "book_id"
const val TITLE = "book_title"
const val AUTHOR = "author_name"
const val COVER = "cover_uri"
const val DURATION = "duration"


data class Book (val book_id: Int,
                 val title: String,
                 val author: String,
                 val coverUri: String,
                 val duration: Int,
                 var bookFile: File? = null)
    : AudioBookPlayerService.AudioBook, AudioBookPlayerService.FileAudioBook, Serializable {


    constructor(book: JSONObject): this (
        book.getInt(ID),
        book.getString(TITLE),
        book.getString(AUTHOR),
        book.getString(COVER),
        book.getInt(DURATION),
    )

    override fun getAudioBookId(): Int {
        return book_id
    }

    override fun getFile(): File? {
        return bookFile
    }

}

data class BookProgress(val time: LocalDateTime, val progress: Int) : Serializable
class BookProgressMap(val bookProgressMap: HashMap<Int, BookProgress> = HashMap()) : Serializable {
    operator fun set(bookId: Int, value: BookProgress) {
        bookProgressMap[bookId] = value
    }
    operator fun get(bookId: Int): BookProgress? = bookProgressMap[bookId]
}

//    fun getJSONBook () : JSONObject {
//        return JSONObject().apply {
////            putInt("book_id", book_id)
//        }
//    }
