package edu.temple.flossplayer

import android.app.SearchManager
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.lifecycle.ViewModelProvider
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley
import edu.temple.flossaudioplayer.AudioBookPlayerService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import java.io.BufferedInputStream
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.FileReader
import java.io.IOException
import java.io.ObjectInputStream
import java.io.ObjectOutputStream
import java.lang.Exception
import java.lang.StringBuilder
import java.net.URL
import java.time.LocalDateTime

class MainActivity : AppCompatActivity(), BookControlFragment.BookControlInterface {

    private val searchURL = "https://kamorris.com/lab/flossplayer/searchbooks.php?query="

    private lateinit var progressSeekBar: SeekBar
    private lateinit var bookServiceIntent: Intent

    private val searchRecordFileName = "search"
    private lateinit var searchRecordFile: File

    private lateinit var audioBookFile: File

    private lateinit var timer: Utility

    private val booksDownloadFileName = "downloadedBooks"
    private lateinit var booksDownloadFile: File
    private var currentProgress = 0
    private lateinit var bookProgressMap: BookProgressMap

    var mediaControllerBinder: AudioBookPlayerService.MediaControlBinder? = null

    val bookProgressHandler = Handler(Looper.getMainLooper()) {

        with (it.obj as AudioBookPlayerService.BookProgress) {

            // Update ViewModel state based on whether we're seeing the currently playing book
            // from the service for the first time
            if (!bookViewModel.hasBookBeenPlayed()) {
                bookViewModel.setBookPlayed(true)
                bookViewModel.setPlayingBook(book as Book)
                bookViewModel.setSelectedBook(book as Book)
            }

            // Update seekbar with progress of current book as a percentage
            progressSeekBar.progress = ((progress.toFloat() / (book as Book).duration) * 100).toInt()
            currentProgress = progress
        }
        true
    }

    // Callback that is invoked when (un)binding is complete
    private val bookServiceConnection = object: ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            mediaControllerBinder = service as AudioBookPlayerService.MediaControlBinder
            mediaControllerBinder?.setProgressHandler(bookProgressHandler)
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            mediaControllerBinder = null
        }

    }

    private val requestQueue : RequestQueue by lazy {
        Volley.newRequestQueue(this)
    }

    private val isSingleContainer : Boolean by lazy{
        findViewById<View>(R.id.container2) == null
    }

    private val bookViewModel : BookViewModel by lazy {
        ViewModelProvider(this)[BookViewModel::class.java]
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        timer = Utility()

        searchRecordFile = File(filesDir, searchRecordFileName)
        if (searchRecordFile.exists()) loadSearchResult()

        booksDownloadFile = File(filesDir, booksDownloadFileName)
        bookProgressMap = if (booksDownloadFile.exists()) readFromFile() else BookProgressMap()

        val nowPlayingTextView = findViewById<TextView>(R.id.nowPlayingTextView)
        progressSeekBar = findViewById<SeekBar?>(R.id.progressSeekBar).apply {
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    if (fromUser) {

                        // If the user is dragging the SeekBar, convert progress percentage
                        // to value in seconds and seek to position
                        bookViewModel.getSelectedBook()?.value?.let {book ->
                            mediaControllerBinder?.run {
                                if (isPlaying) {
                                    seekTo(((progress.toFloat() / 100) * book.duration).toInt())
                                }
                            }
                        }
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {}

                override fun onStopTrackingTouch(seekBar: SeekBar?) {}

            })
        }

        // Use Back gesture to clear selected book
        val backPressCallback = object: OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // BackPress clears the selected book
                bookViewModel.clearSelectedBook()
                Log.d("Back", "Pressed")
                // Remove responsibility for handling back gesture
                isEnabled = false
                // Trigger back gesture
                onBackPressedDispatcher.onBackPressed()
            }
        }

        onBackPressedDispatcher.addCallback(backPressCallback)

        // If we're switching from one container to two containers
        // clear BookPlayerFragment from container1
        if (supportFragmentManager.findFragmentById(R.id.container1) is BookPlayerFragment) {
            supportFragmentManager.popBackStack()
        }

        // If this is the first time the activity is loading, go ahead and add a BookListFragment
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.container1, BookListFragment())
                .commit()
        } else
        // If activity loaded previously, there's already a BookListFragment
        // If we have a single container and a selected book, place it on top
            if (isSingleContainer && bookViewModel.getSelectedBook()?.value != null) {
                supportFragmentManager.beginTransaction()
                    .replace(R.id.container1, BookPlayerFragment())
                    .setReorderingAllowed(true)
                    .addToBackStack(null)
                    .commit()
            }

        // If we have two containers but no BookPlayerFragment, add one to container2
        if (!isSingleContainer && supportFragmentManager.findFragmentById(R.id.container2) !is BookPlayerFragment)
            supportFragmentManager.beginTransaction()
                .add(R.id.container2, BookPlayerFragment())
                .commit()


        // Respond to selection in portrait mode using flag stored in ViewModel
        bookViewModel.getSelectedBook()?.observe(this){
            if (!bookViewModel.hasViewedSelectedBook()) {
                backPressCallback.isEnabled = true
                if (isSingleContainer) {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.container1, BookPlayerFragment())
                        .setReorderingAllowed(true)
                        .addToBackStack(null)
                        .commit()
                }
                bookViewModel.markSelectedBookViewed()
            }
        }

        // Always show currently playing book
        bookViewModel.getPlayingBook()?.observe(this){
            nowPlayingTextView.text = String.format(getString(R.string.now_playing), it.title)
        }

        findViewById<View>(R.id.searchImageButton).setOnClickListener {
            onSearchRequested()
        }

        bookServiceIntent = Intent(this, AudioBookPlayerService::class.java)

        // Bind in order to send commands
        bindService(bookServiceIntent, bookServiceConnection, BIND_AUTO_CREATE)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)

        if (Intent.ACTION_SEARCH == intent!!.action) {
            intent.getStringExtra(SearchManager.QUERY)?.also {
                searchBooks(it)

                // Unselect previous book selection
                bookViewModel.clearSelectedBook()

                // Remove any unwanted DisplayFragments instances from the stack
                supportFragmentManager.popBackStack()
            }
        }

    }

    private fun searchBooks(searchTerm: String) {
        requestQueue.add(
            JsonArrayRequest(searchURL + searchTerm,
                {
                    bookViewModel.updateBooks(it)
                    saveSearchResult(it)},
                { Toast.makeText(this, it.networkResponse.toString(), Toast.LENGTH_SHORT).show() })
        )
    }

    private fun saveSearchResult(objArray: JSONArray) {
        try {
            val outputStream = FileOutputStream(searchRecordFile)
            outputStream.write(objArray.toString().toByteArray())
            outputStream.close()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun loadSearchResult() {
        try {
            val br = BufferedReader(FileReader(searchRecordFile))
            val text = StringBuilder()
            var line: String?
            while (br.readLine().also { line = it } != null) {
                text.append(line)
                text.append('\n')
            }
            br.close()

            try {
                bookViewModel.updateBooks(JSONArray(text.toString()))
            } catch (e: JSONException) {
                searchRecordFile.delete()
            }

        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    override fun playBook() {
        bookViewModel.getSelectedBook()?.value?.apply {
            mediaControllerBinder?.run {

                bookViewModel.getPlayingBook()?.value?.run {
                    if (this.book_id != this@apply.book_id) savePlayingBook()
                }

                audioBookFile = File(filesDir, getFileName(this@apply))

                if (audioBookFile.exists()) {
                    this@apply.bookFile = audioBookFile
                    bookProgressMap[this@apply.book_id]?.run {
                        val position = if (this.progress - timer.getRewindTime(this.time) < 0) 0 else this.progress - timer.getRewindTime(this.time)
                        play(this@apply as AudioBookPlayerService.FileAudioBook, position)
                    }
                } else {
                    play(this@apply)

                    CoroutineScope(Dispatchers.Default).launch {
                        downloadAudio(this@apply)
                    }
                }
                bookViewModel.setPlayingBook(this@apply)
                bookViewModel.setBookPlayed(false)

                // Start service to ensure it keeps playing even if the activity is destroyed
                startService(bookServiceIntent)
            }
        }
    }

    override fun pauseBook() {
        mediaControllerBinder?.run {
            if (isPlaying) {
                savePlayingBook()
                stopService(bookServiceIntent)
            } else {
                bookViewModel.getPlayingBook()?.value?.run {
                    bookProgressMap[this.book_id]?.run {
                        val position = if (this.progress - timer.getRewindTime(this.time) < 0) 0 else this.progress - timer.getRewindTime(this.time)
                        seekTo(position)
                    }
                }
                startService(bookServiceIntent)
            }
            pause()
        }
    }

    private fun savePlayingBook() {
        Log.d("Saving", "Starting ----- Book is being saved")
        bookViewModel.getPlayingBook()?.value?.run {
            val progress = BookProgress(LocalDateTime.now(), currentProgress)
            bookProgressMap[this.book_id] = progress
            Log.d("Saving", "Book progress is being saved")
        }
    }

    private fun writeToFile(data: BookProgressMap) {
        try {
            ObjectOutputStream(FileOutputStream(booksDownloadFile)).use { fileOut ->
                fileOut.writeObject(data)
            }
            Log.d("Writing","Data written to $booksDownloadFileName")
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }


    private fun readFromFile(): BookProgressMap {
        return try {
            ObjectInputStream(FileInputStream(booksDownloadFile)).use { fileIn ->
                fileIn.readObject() as BookProgressMap
            }
        } catch (e: IOException) {
            e.printStackTrace()
            BookProgressMap()
        } catch (e: ClassNotFoundException) {
            e.printStackTrace()
            BookProgressMap()
        } catch (e: FileNotFoundException) {
            e.printStackTrace()
            BookProgressMap()
        }

    }

    private fun getFileName(book: Book) : String {
        return "book${book.getAudioBookId()}"
    }


    private suspend fun downloadAudio(book: Book) {
        audioBookFile = File(filesDir, getFileName(book))
        val url = "https://kamorris.com/lab/flossplayer/downloadbook.php?id=${book.getAudioBookId()}"

        URL(url).openConnection().run {
            withContext(Dispatchers.IO) {
                BufferedInputStream(this@run.getInputStream()).use { inputStream ->
                    FileOutputStream(audioBookFile).use { outputStream ->
                        val buffer = ByteArray(4096)
                        var bytesRead: Int
                        while (inputStream.read(buffer).also { bytesRead = it } != -1) {
                            outputStream.write(buffer, 0, bytesRead)
                        }
                        outputStream.flush()
                        Log.d("File downloaded successfully to", audioBookFile.toString())
                    }
                }
            }
        }
    }

    override fun onStop() {
        writeToFile(bookProgressMap)
        super.onStop()
    }

    override fun onPause() {
        writeToFile(bookProgressMap)
        super.onPause()
    }
    override fun onDestroy() {
        unbindService(bookServiceConnection)
        super.onDestroy()
    }
}


//    private fun updateBooksToFile(book: Book) {
//        var found = false
//        val books = getBooksFromFile().apply {
//            for (i in 0 until this.length()) {
//                if (Book(this.getJSONObject(i)).book_id == book.book_id ) {
//                    this.put(i, book.getJSONBook())
//                    found = true
//                    Log.d("Message", "${book.title} being saved")
//                }
//            }
//            if(!found)
//                this.put(book.getJSONBook())
//                Log.d("Message", "${book.title} being added")
//        }
//
//        try {
//            val outputStream = FileOutputStream(booksDownloadFile)
//            outputStream.write(books.toString().toByteArray())
//            Log.d("Message", "Books being written to file")
//            outputStream.close()
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//
//    private fun getBooksFromFile() : JSONArray {
//        try {
//            val br = BufferedReader(FileReader(booksDownloadFile))
//            val text = StringBuilder()
//            var line: String?
//            while (br.readLine().also { line = it } != null) {
//                text.append(line)
////                text.append('\n')
//            }
//            br.close()
//
//            text.toString()
//            return JSONArray(text.toString())
//
//        } catch (e: IOException) {
//            e.printStackTrace()
//            return JSONArray()
//        }
//    }

