

//Utility Class Overview:

class Utility {
    fun getRewindTime(pausedTime: LocalDateTime) : Int {
        val elapsedTime = Duration.between(pausedTime, LocalDateTime.now()).seconds
        return when {
            elapsedTime < 60L -> 5
            elapsedTime < 60L * 5 -> 15
            elapsedTime < 60L * 60 -> 30
            else -> 60
        }
    }
}













//Dynamic Screen Adaptation:

// If we're switching from one container to two containers
// clear BookPlayerFragment from container1
if (supportFragmentManager.findFragmentById(R.id.container1) is BookPlayerFragment) {
    supportFragmentManager.popBackStack()
}

// If we have two containers but no BookPlayerFragment, add one to container2
if (!isSingleContainer && supportFragmentManager.findFragmentById(R.id.container2) !is BookPlayerFragment)
supportFragmentManager.beginTransaction()
.add(R.id.container2, BookPlayerFragment())
.commit()

