package edu.temple.flossplayer

import java.time.Duration
import java.time.LocalDateTime

class Utility {
    fun getRewindTime(pausedTime: LocalDateTime) : Int {
        val elapsedTime = Duration.between(pausedTime, LocalDateTime.now()).seconds

        return when {
            elapsedTime < 60L -> 5
            elapsedTime < 60L * 5 -> 15
            elapsedTime < 60L * 60 -> 30
            else -> 60
        }
    }
}