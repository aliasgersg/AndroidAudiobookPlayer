package edu.temple.flossplayer

import org.junit.Test
import org.junit.Assert.*
import org.junit.Before
import java.sql.Time
import java.time.Duration
import java.time.LocalDateTime
import java.time.temporal.ChronoUnit

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {

    lateinit var bookList: BookList

    @Before
    fun setUp() {
        bookList = BookList()
    }

    @Test
    fun addBook() {
        val book = Book(1, "Test Book", "Author", "coverUri", 100)
        bookList.add(book)
        assertEquals(book, bookList[0])
    }

    @Test
    fun removeBook() {
        val book = Book(1, "Test Book", "Author", "coverUri", 100)
        bookList.add(book)
        bookList.remove(book)
        assertEquals(0, bookList.size())
    }

    @Test
    fun clearBookList() {
        bookList.add(Book(1, "Book1", "Author1", "coverUri1", 100))
        bookList.add(Book(2, "Book2", "Author2", "coverUri2", 100))
        bookList.clear()
        assertEquals(0, bookList.size())
    }

    @Test
    fun getBookByIndex() {
        val book1 = Book(1, "Book1", "Author1", "coverUri1", 100)
        val book2 = Book(2, "Book2", "Author2", "coverUri2", 100)
        bookList.add(book1)
        bookList.add(book2)
        assertEquals(book2, bookList[1])
    }

    @Test
    fun bookListSize() {
        bookList.add(Book(1, "Book1", "Author1", "coverUri1", 100))
        bookList.add(Book(2, "Book2", "Author2", "coverUri2", 100))
        assertEquals(2, bookList.size())
    }
}